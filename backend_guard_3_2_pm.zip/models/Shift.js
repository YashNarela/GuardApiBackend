const mongoose = require("mongoose");






const shiftSchema = new mongoose.Schema(
  {
    shiftName: { type: String},
    // guard: {
    //   type: mongoose.Schema.Types.ObjectId,
    //   ref: "User",
    //   required: true,
    // },

    assignedGuards: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "User",
      },
    ],
    isActive: { type: Boolean, default: true },
    startTime: { type: Date, required: true },
    endTime: { type: Date, required: true },
    shiftType: { type: String, enum: ["day", "night", "both"], default: "day" },
    createdBy: { type: mongoose.Schema.Types.ObjectId, ref: "User" }, // employee/admin
  },
  { timestamps: true }
);
module.exports = mongoose.model("Shift", shiftSchema);