// controllers/shiftController.js
const Shift = require("../models/Shift");
const ApiResponse = require("../utils/apiResponse");
const PatrolPlan = require("../models/PatrolPlan");

// exports.createShift = async (req, res) => {
//   try {

//     console.log('req is ', req.user);

    
    
    
//     const { guardId, startTime, endTime, shiftType } = req.body;
//     if (!guardId || !startTime || !endTime) {
//       return res.status(400).json(new ApiResponse(false, "All fields required"));
//     }

//     const shift = await Shift.create({
//       guard: guardId,
//       startTime: new Date(startTime),
//       endTime: new Date(endTime),
//       createdBy: req.user.id,
//       shiftType: shiftType,
//     });

//     return res.status(201).json(new ApiResponse(true, "Shift created", shift));
//   } catch (err) {
//     return res.status(500).json(new ApiResponse(false, err.message));
//   }
// };

// controllers/shiftController.js


  // exports.createShift = async (req, res) => {
  //   try {
  //     console.log("req.user ===>", req.user);

  //     const { shiftName, shiftType, startTime, endTime, assignedGuards } =
  //       req.body;

  //     // Validation
  //     if (
  //       !shiftName ||
  //       !startTime ||
  //       !endTime ||
  //       !assignedGuards ||
  //       assignedGuards.length === 0
  //     ) {
  //       return res
  //         .status(400)
  //         .json(
  //           new ApiResponse(
  //             false,
  //             "Shift name, timings, and at least one guard are required"
  //           )
  //         );
  //     }

  //    const start = new Date(startTime);
  //   const end = new Date(endTime);


  //     const shift = await Shift.create({
  //       shiftName,
  //       assignedGuards,
  //     startTime: start.toISOString(), // store UTC
  //     endTime: end.toISOString(),
  //       shiftType: shiftType || "day",
  //       createdBy: req.user.id,
  //     });

  //     return res
  //       .status(201)
  //       .json(new ApiResponse(true, "Shift created successfully", shift));
  //   } catch (err) {
  //     console.error("Error creating shift:", err);
  //     return res.status(500).json(new ApiResponse(false, err.message));
  //   }
  // };
exports.createShift = async (req, res) => {
  try {
    const { shiftName, shiftType, startTime, endTime, assignedGuards } = req.body;

    if (!shiftName || !startTime || !endTime || !assignedGuards?.length) {
      return res.status(400)
        .json(new ApiResponse(false, "Shift name, timings, and at least one guard are required"));
    }

    const start = new Date(startTime);
    const end = new Date(endTime);
    const now = new Date();

    if (isNaN(start) || isNaN(end)) {
      return res.status(400).json(new ApiResponse(false, "Invalid start or end time format"));
    }

    if (start < now) {
      return res.status(400).json(new ApiResponse(false, "Shift start time cannot be in the past"));
    }

    if (end <= start) {
      return res.status(400).json(new ApiResponse(false, "End time must be after start time"));
    }

    // Overlap check
    const overlap = await Shift.findOne({
      assignedGuards: { $in: assignedGuards },
      isActive: true,
      startTime: { $lt: end },
      endTime: { $gt: start }
    });

    if (overlap) {
      return res.status(400)
        .json(new ApiResponse(false, "One or more guards already have an overlapping shift"));
    }

    const shift = await Shift.create({
      shiftName,
      assignedGuards,
      startTime: start.toISOString(),
      endTime: end.toISOString(),
      shiftType: shiftType || "day",
      createdBy: req.user.id,
    });

    return res.status(201).json(new ApiResponse(true, "Shift created successfully", shift));
  } catch (err) {
    console.error("Error creating shift:", err);
    return res.status(500).json(new ApiResponse(false, err.message));
  }
};

exports.getShifts = async (req, res) => {
  try {
    let filter = {};

    if (req.user.role === "supervisor") {
      filter = { createdBy: req.user.id };
    }

    const shifts = await Shift.find(filter).populate(
      "assignedGuards",
      "name email"
    );

    return res
      .status(200)
      .json(new ApiResponse(true, "Shifts fetched", shifts));
  } catch (err) {
    return res.status(500).json(new ApiResponse(false, err.message));
  }
};


exports.deleteShift = async (req, res) => {
  try {
    const filter = { _id: req.params.id };
    if (req.user.role === "supervisor") {
      filter.createdBy = req.user.id;
    }

    const deleted = await Shift.findOneAndDelete(filter);

    if (!deleted) {
      return res.status(404).json(new ApiResponse(false, "Shift not found"));
    }

    return res
      .status(200)
      .json(new ApiResponse(true, "Shift deleted successfully"));
  } catch (err) {
    return res.status(500).json(new ApiResponse(false, err.message));
  }
};


// exports.updateShift = async (req, res) => {
//   try {
//     const { shiftName, startTime, endTime, shiftType, assignedGuards } =
//       req.body;


//     console.log('Update Shift Req Body:', req.body);
    

//     const filter = { _id: req.params.id };
//     if (req.user.role === "supervisor") filter.createdBy = req.user.id;

//     const updateData = {};
//     if (startTime) {
//       const start = new Date(startTime);
//       if (isNaN(start)) {
//         return res.status(400).json(new ApiResponse(false, "Invalid start time format"));
//       }
//       updateData.startTime = start.toISOString(); // enforce UTC
//     }

//     if (endTime) {
//       const end = new Date(endTime);
//       if (isNaN(end)) {
//         return res.status(400).json(new ApiResponse(false, "Invalid end time format"));
//       }
//       updateData.endTime = end.toISOString(); // enforce UTC
//     }

//     if (shiftType) {
//       updateData.shiftType = shiftType;
//     }

//       if (assignedGuards && assignedGuards.length > 0) {
//         updateData.assignedGuards = assignedGuards;
//       }

//     const updated = await Shift.findOneAndUpdate(filter, updateData, {
//       new: true,
//     }).populate("assignedGuards", "name email role");

//     if (!updated) {
//       return res.status(404).json(new ApiResponse(false, "Shift not found"));
//     }

//     return res
//       .status(200)
//       .json(new ApiResponse(true, "Shift updated", updated));
//   } catch (err) {
//     return res.status(500).json(new ApiResponse(false, err.message));
//   }
// };
exports.updateShift = async (req, res) => {
  try {
    const { shiftName, startTime, endTime, shiftType, assignedGuards } = req.body;

    const filter = { _id: req.params.id };
    if (req.user.role === "supervisor") filter.createdBy = req.user.id;

    const updateData = {};
    const now = new Date();
    let newStart, newEnd;

    if (startTime) {
      newStart = new Date(startTime);
      if (isNaN(newStart)) return res.status(400).json(new ApiResponse(false, "Invalid start time format"));
      if (newStart < now) return res.status(400).json(new ApiResponse(false, "Shift start time cannot be in the past"));
      updateData.startTime = newStart.toISOString();
    }

    if (endTime) {
      newEnd = new Date(endTime);
      if (isNaN(newEnd)) return res.status(400).json(new ApiResponse(false, "Invalid end time format"));
      updateData.endTime = newEnd.toISOString();
    }

    // Validate end > start
    if (newStart && newEnd && newEnd <= newStart) {
      return res.status(400).json(new ApiResponse(false, "End time must be after start time"));
    }

    if (shiftType) updateData.shiftType = shiftType;
    if (assignedGuards?.length) updateData.assignedGuards = assignedGuards;

    // Overlap check
    if ((newStart || newEnd) && assignedGuards?.length) {
      const currentShift = await Shift.findById(req.params.id);
      if (!currentShift) return res.status(404).json(new ApiResponse(false, "Shift not found"));

      const overlapStart = newStart || currentShift.startTime;
      const overlapEnd = newEnd || currentShift.endTime;

      const overlap = await Shift.findOne({
        _id: { $ne: req.params.id },
        assignedGuards: { $in: assignedGuards },
        isActive: true,
        startTime: { $lt: overlapEnd },
        endTime: { $gt: overlapStart }
      });

      if (overlap) {
        return res.status(400).json(new ApiResponse(false, "One or more guards already have an overlapping shift"));
      }
    }

    const updated = await Shift.findOneAndUpdate(filter, updateData, { new: true })
      .populate("assignedGuards", "name email role");

    if (!updated) return res.status(404).json(new ApiResponse(false, "Shift not found"));

    return res.status(200).json(new ApiResponse(true, "Shift updated", updated));

  } catch (err) {
    console.error("Error updating shift:", err);
    return res.status(500).json(new ApiResponse(false, err.message));
  }
};
